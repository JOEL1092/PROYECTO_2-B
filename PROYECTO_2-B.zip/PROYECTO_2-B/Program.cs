﻿//Proyecto 2 - sistema de parqueos
//Kevin Joel Atz Amaya caner:2001025

using System;
using PROYECTO_2.Clases;
class Program
{// declaramos las variables que se utilizaran para los datos de inicializar el sistema
    static int Nivel;//variable para aguardar la cantidad de niveles
    static int EspaciosPorNivel;//variable para guardar la cantidad de espacios por cada nivel
    static double PrecioPorHora;//variable para guardar el precio por hora del parqueo
    static int EspaciosMotos;//variable para guardar la cantidad de espacios para motos
    static int EspaciosSuv;//variable para guardar la cantidad de espacios para Suv
    static int EspaciosEstandar;//variable para guardar la cantidad de espacios para estandar 
    static int EspaciosTotal;//variable para guardar la cantidad de espacios en total de todos los niveles y tipos
    static Parqueo parqueo;//llamamos la clase parqueo el cual va a realizar las acciones y contienen los procedimientos 
    static Pago pago;//llamamos la calse de pago el cual realiza los calculos del total que debe pagar el usuario
    static void Main(string[] args)
    {
        InicializarSistema();//llamamos la funcion para inicializar el sistema
        Menu();//llamamos la funcion del menu principal
    }
    static void InicializarSistema()//funcion de inicializacion del sistema
    {
        bool ValidacionDeDatos = false;//esta variable guardara si la validacion de los datos es falso o verdadero

        while (!ValidacionDeDatos)//creamos un ciclo que se repite hasta que ingresen los datos correctos
        {
            Console.WriteLine("--------------Bienvenido Usuario-------------------");
            Console.WriteLine("Para iniciaizar el sistema de parqueos ingrese los siguientes datos:");
            Console.WriteLine();
            Console.WriteLine("-----Datos de Inicializacion-----");


            while (true)//ciclo que se repite hasta ingresar una cantidad de niveles que no sea 0
            {
                Console.Write("Cantidad de Niveles: ");
                try
                {
                    Nivel = int.Parse(Console.ReadLine());
                    if (Nivel > 0) break;
                    Console.WriteLine("Error: Al menos debe de haber 1 nivel");
                }
                catch (FormatException)//creamos una excepcion si ingresa un dato que no sea entero
                {
                    Console.WriteLine("Error: Ingrese un numero valido");
                }
            }

            while (true)//ciclo que se repite hasta que ingresen un numero mayor a 0
            {
                Console.Write("Cantidad de Espacios por Nivel: ");
                try
                {
                    EspaciosPorNivel = int.Parse(Console.ReadLine());
                    if (EspaciosPorNivel > 0) break;
                    Console.WriteLine("Error: El número debe ser mayor que cero");
                }
                catch (FormatException)//creamos una excepcion si ingresa un dato que no sea entero
                {
                    Console.WriteLine("Error: Ingrese un numero valido");
                }
            }

            EspaciosTotal = Nivel * EspaciosPorNivel;//calculamos los espacios totales
            Console.WriteLine("Espacios total es de: " + EspaciosTotal);

            while (true)//ciclo que se repite hasta que ingresen un precio ya sea entero o con decimales (centavos)
            {
                Console.Write("Precio por Hora: Q");
                try
                {
                    PrecioPorHora = double.Parse(Console.ReadLine());
                    if (PrecioPorHora > 0) break;
                    Console.WriteLine("Error: El precio debe ser mayor que cero");
                }
                catch (FormatException)//creamos una excepcion si ingresa un dato que no sea entero mayor a 0
                {
                    Console.WriteLine("Error: Ingrese un precio valido (si tiene centavos ingreselos con por ejemplo: 10.50)");
                }
            }
            while (true)//ciclo que se repite hasta que ingresen una cantidad mayor a 0 que sea menor al espacio total
            {
                Console.Write("Cantidad de Espacios para Motos: ");
                try
                {
                    EspaciosMotos = int.Parse(Console.ReadLine());
                    if (EspaciosMotos >= 0 && EspaciosMotos <= EspaciosTotal) break;
                    Console.WriteLine("Error: El número debe ser positivo y no debe de ser mayor a los espacios totales");
                }
                catch (FormatException)//creamos una excepcion si ingresa un numero mayor a la cantidad de espacios totales o no es un entero mayor a 0
                {
                    Console.WriteLine("Error: Ingrese un numero valido");
                }
            }
            while (true)//ciclo que se repite hasta que ingresen una cantidad mayor o igual a 0 y que su suma con la de motos sea manor o igual a los espacios totales
            {
                Console.Write("Cantidad de Espacios para SUV: ");
                try
                {
                    EspaciosSuv = int.Parse(Console.ReadLine());
                    if (EspaciosSuv >= 0 && (EspaciosMotos + EspaciosSuv) <= EspaciosTotal) break;
                    Console.WriteLine("Error: El número debe ser positivo y la suma de espacios para motos y SUV no debe ser mayor a la capacidad total");
                }
                catch (FormatException)//creamos una excepcion si ingresan un valor menor a 0 o que no sea un entero
                {
                    Console.WriteLine("Error: Ingrese un numero valido");
                }
            }

            EspaciosEstandar = (EspaciosTotal - EspaciosMotos) - EspaciosSuv;//calculamos la cantidad de espacios estandar
            Console.WriteLine("Cantidad de Espacios para Estandar:  " + EspaciosEstandar);
            Console.WriteLine();

            Console.WriteLine("Estas seguro que son los datos correcto (Ingrese 'Si' para validar / 'No' para volver a ingresar)");//validamos si son correctos los datos
            string R = Console.ReadLine().Trim().ToUpper();

            while (R != "SI" && R != "NO")//ciclo que se repite hasta que sea un Si o No para los datos sean correctos
            {
                Console.WriteLine("¿Estás seguro que los datos son correctos? (Ingrese 'Si' para validar / 'No' para corregir): ");
                R = Console.ReadLine().Trim().ToUpper();

                if (R != "SI" && R != "NO")//si la respuesta es diferente a Si o No se vuelve a pedir una respuesta valida
                {
                    Console.WriteLine("Opcion inválida, escriba 'Si' para continuar o 'No' para corregir datos");
                }
            }
            if (R == "SI")//si la respuesta es si se confirma los datos
            {
                ValidacionDeDatos = true;//cambiamos la validacion a verdadero
                Console.WriteLine("Datos confirmados");
                Console.WriteLine("Inicializando Sistema...");
                Console.WriteLine();

                parqueo = new Parqueo(Nivel, EspaciosPorNivel, PrecioPorHora, EspaciosMotos, EspaciosSuv);//creamos una instania de la clase paqueos
                parqueo.InicializarEstacionamientos();//llamamos la inicializacion que esta en la clase parqueos
            }
            else// si la respuesta es No volvemos a pedir los datos de inicializacion
            {
                Console.WriteLine();
                Console.WriteLine("Corregir datos");
            }
        }
    }
    static void Menu() //funcion de menu
    {
        string opcionElegido = "";
        int opciones = 0;//variable que guarda la opcion elegifa por el usuario

        while (opciones != 7)//ciclo que se repite hasta que el usuario desea salir de sistema con la opcion 7
        {
            Console.WriteLine();
            Console.WriteLine("------------------MENÚ------------------");
            Console.WriteLine("Ingrese el numero de las opcion que desea:");
            Console.WriteLine("1. Ingresar un vehículo manualmente");
            Console.WriteLine("2. Ingresar lote de vehículos");
            Console.WriteLine("3. Encontrar un vehículo");
            Console.WriteLine("4. Retirar un vehículo");
            Console.WriteLine("5. Mostrar estado general del parqueo");
            Console.WriteLine("6. Generar reporte de vehículos estacionados");
            Console.WriteLine("7. Salir");

            opcionElegido = Console.ReadLine();

            if (int.TryParse(opcionElegido, out opciones))//convertimos la opcion ingresado en un valor de dato entero
            {
                if (opciones >= 1 && opciones <= 7)//si la opcion esta entre 1 y 7 realizara la siguientes opciones
                {
                    switch (opciones)
                    {
                        case 1://realiza la accion de ingresar un vehiculo manualmente
                            Console.WriteLine("---------------Ingresar un vehículo manualmente-------------------");
                            Console.WriteLine();
                            parqueo.IngresarVehiculos();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 2://realiza la accion de ingresar un lote de 5 vehiculo automaticamente
                            Console.WriteLine("--------------------Ingresar lote de vehículos-----------------------");
                            Console.WriteLine();
                            parqueo.IngresarLotedeVehiculos();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 3://realiza la accion de encontrar un vehiculo pormedio de la placa
                            Console.WriteLine("------------------------Encontrar un vehículo-------------------------");
                            Console.WriteLine();
                            parqueo.BuscarVehiculos();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 4://realiza la accion de retirar un vehiculo y los calculos del monto a pagar
                            Console.WriteLine("--------------------Retirar un vehículo---------------------------");
                            Console.WriteLine();
                            parqueo.RetirarVehiculo();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 5://realiza la accion de mostrar el estado general del parqueo con su matriz
                            Console.WriteLine("------------------------------Mostrar estado general del parqueo----------------------------");
                            Console.WriteLine();
                            parqueo.MostrarEstadoParqueo();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 6://realiza la accion de genera un reporte de vehiculo segun por la hora de entrada o codigo de espacio
                            Console.WriteLine("-----------------------Generar reporte de vehículos estacionados-------------------------------");
                            Console.WriteLine();
                            parqueo.ReporteDeVehiculosEstacionados();//llamamos a la calse parqueos que tienen la accion
                            break;

                        case 7://realiza la accion de salirse del programa si el usuario de desea
                            Console.WriteLine("-----------------Salir-----------------");
                            Console.WriteLine("Gracias por utilizar nuestro parqueos, vuelva pronto");
                            Environment.Exit(0);//finaliza el codigo 
                            break;
                        default:
                            Console.WriteLine("Opción inválida, intente otra vez");
                            break;
                    }
                }
            }
        }
    }
}

