using System;

namespace PROYECTO_2.Clases
{
    public class Pago//clase que guardar los datos del pago
    {
        public static void CalcularPago(Parqueo parqueo, Estacionamiento espacio, double PrecioPorHora)//funcion que calcula el pago y retira el vehiculo
        {
            if (espacio.Disponibilidad || espacio.VehiculoAsignado == null)//compara la disponibilida y asignacion del espacio
            {
                Console.WriteLine("No se encontró un vehículo en ese espacio");
                return;
            }

            Vehiculos vehiculo = espacio.VehiculoAsignado;//llamamos la clase de vehiculos
            int HoraEntrada = vehiculo.GetHoraEntrada().Hour;//variable que guarda la hora de entrada
            int Tiempo = new Random().Next(1, 24 - HoraEntrada);//un random da la hora que se respara el viaej
            double Monto = Tiempo * PrecioPorHora;//variable que clacula el monto total

            Console.WriteLine("Pago");
            Console.WriteLine("Datos del Vehiculo");
            Console.WriteLine("Placas: " + vehiculo.GetPlaca());
            Console.WriteLine("Marca: " + vehiculo.GetMarca());
            Console.WriteLine("Color: " + vehiculo.GetColor());
            Console.WriteLine("Tiempo de Parqueo: " + Tiempo + " horas");
            Console.WriteLine($"Total a pagar: Q{Monto:N2}");

            Console.WriteLine("Seleccione método de pago:");
            Console.WriteLine("1. Tarjeta");
            Console.WriteLine("2. Efectivo");

            int FormadePago;
            while (!int.TryParse(Console.ReadLine(), out FormadePago) || (FormadePago < 1 || FormadePago > 2))//comparamos la opcion elegida por el usuario y el del requisito
            {
                Console.WriteLine("Opción inválida, ingrese 1 o 2");
            }

            if (FormadePago == 1)//si la respuesta es 1 paga con tarjeta
            {
                Console.WriteLine("Se realizo el pago con tarjeta");
            }
            else//si la respuesta es 2 paga con efectivo y realiza el calculo
            {
                Console.Write("Ingrese el monto con el que pagará: Q");
                double MontoIngresado;
                while (!double.TryParse(Console.ReadLine(), out MontoIngresado) || MontoIngresado < Monto)
                {
                    Console.WriteLine("Error: El monto debe ser igual o mayor a Q" + Monto);
                }

                double Cambio = MontoIngresado - Monto;//clacula el cambio

                if (Cambio > 0)//devuelve el cambio si es mayor al motno total
                {
                    Console.WriteLine("Cambio entregado");
                    double[] valores = { 100, 50, 20, 10, 5, 1, 0.50, 0.25, 0.10, 0.05, 0.01 };
                    for (int i = 0; i < valores.Length; i++)
                    {
                        if (Cambio >= valores[i])//buscamoe el cambio mas cercano
                        {
                            int cantidad = (int)(Cambio / valores[i]);
                            Cambio -= cantidad * valores[i];
                            Console.WriteLine("Q" + valores[i] + ":" + cantidad);
                        }
                    }
                }
                else//si es exacto el pago en efectivo 
                {
                    Console.WriteLine("Gracias, pago exacto");
                }
            }
            espacio.LiberarEspacio();//llamamo la clase de liberar en espacio
            Console.WriteLine();
            Console.WriteLine("Vehículo retirado");
            Console.WriteLine("Gracias por usar Nuestros Parqueos, Vuelva pronto");
            Console.WriteLine();
            parqueo.MostrarEstadoParqueo();//llamamos la clase de mostrar la matriz de espacios
        }
        public static void RetirarVehiculo(Parqueo parqueo)//funcion que encapsula los datos ingresado para retira vehiculo
        {
            Console.Write("Ingrese el código del estacionamiento del vehículo: ");
            string Codigo = Console.ReadLine().Trim().ToUpper();

            var espacio = parqueo.BuscarCodigo(Codigo);//busca el codigo en la matriz

            if (espacio == null || espacio.Disponibilidad || espacio.VehiculoAsignado == null)//compara las caracteristicas que deben de cumplir
            {
                Console.WriteLine("No se encontró un vehículo en ese espacio");
                return;
            }

            CalcularPago(parqueo,espacio, parqueo.GetPrecioPorHora());//llamamos la funcion de clacularPago
        }
    }
}