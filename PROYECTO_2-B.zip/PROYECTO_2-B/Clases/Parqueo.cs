using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;

namespace PROYECTO_2.Clases
{
    public class Parqueo//clase que contienen las variables para parqueos
    {
        private int Nivel;
        private int EspaciosPorNivel;
        private double PrecioPorHora;
        private int EspaciosMotos;
        private int EspaciosSuv;
        private int EspaciosEstandar;
        public List<Estacionamiento> Espacios;


        public Parqueo(int Nivel, int EspaciosPorNivel, double PrecioPorHora, int EspaciosMotos, int EspaciosSuv)//contructores de los objetos
        {
            this.Nivel = Nivel;
            this.EspaciosPorNivel = EspaciosPorNivel;
            this.PrecioPorHora = PrecioPorHora;
            this.EspaciosMotos = EspaciosMotos;
            this.EspaciosSuv = EspaciosSuv;
            this.EspaciosEstandar = (Nivel * EspaciosPorNivel) - EspaciosMotos - EspaciosSuv;
            this.Espacios = new List<Estacionamiento>();
        }

        public void SetNivel(int Nivel)//metodos de las varaibles
        {
            this.Nivel = Nivel;
        }
        public int GetNivel()
        {
            return this.Nivel;
        }
        public void SetPrecioPorHora(double PrecioPorHora)
        {
            this.PrecioPorHora = PrecioPorHora;
        }

        public double GetPrecioPorHora()
        {
            return this.PrecioPorHora;
        }
        public void InicializarEstacionamientos()//funcion que incializa los parametrod de los espacios
        {
            int cantMoto = 1;
            int cantSuv = 1;
            int cantEstandar = 1;

            for (int i = 1; i <= Nivel; i++)
            {
                for (int j = 1; j <= EspaciosPorNivel; j++)
                {
                    string codigo;
                    string tipo;

                    if (cantMoto <= EspaciosMotos)
                    {
                        codigo = "M" + cantMoto;
                        tipo = "Moto";
                        cantMoto++;
                    }
                    else if (cantSuv <= EspaciosSuv)
                    {
                        codigo = "S" + cantSuv;
                        tipo = "SUV";
                        cantSuv++;
                    }
                    else
                    {
                        codigo = "E" + cantEstandar;
                        tipo = "Estandar";
                        cantEstandar++;
                    }

                    Estacionamiento espacio = new Estacionamiento(codigo, tipo, i, true);
                    Espacios.Add(espacio);
                }
            }

            Console.WriteLine(Espacios.Count + " espacios del estacionamiento fueron habilitados");
        }
        public void AgregarEstacionamiento(Estacionamiento estacionamiento)//funcion que agregara un espacio en el estacionamiento 
        {
            if (Espacios.Count < (Nivel * EspaciosPorNivel))
            {
                Espacios.Add(estacionamiento);
                Console.WriteLine("Espacio en el estacionamiento agregado");
            }
            else
            {
                Console.WriteLine("No hay espacios disponibles");
            }
        }

        public bool AsignarEspacio(Vehiculos vehiculo)//se asigna el espacion a un vehiculo segun su tipo
        {
            foreach (var espacio in Espacios)
            {
                if (espacio.Disponibilidad && espacio.Tipo.Equals(vehiculo.GetTipo(), StringComparison.OrdinalIgnoreCase))
                {
                    return espacio.AsignarVehiculo(vehiculo);
                }
            }

            Console.WriteLine("No hay espacios disponibles para vehículos tipo " + vehiculo.GetTipo());
            return false;
        }

        public void LiberarEstacionamiento(string placa)//se realiza la liberacion del espacio al retirarse el vehiculo
        {
            foreach (var espacio in Espacios)//conteo por cada espacio para buscar la placa del vehicuolo que se quiere liberar
            {
                if (!espacio.Disponibilidad && espacio.VehiculoAsignado != null &&
                    espacio.VehiculoAsignado.GetPlaca().Equals(placa, StringComparison.OrdinalIgnoreCase))
                {
                    espacio.LiberarEspacio();
                    return;
                }
            }
            Console.WriteLine("No se encontró un vehículo con placa " + placa + " en el parqueo");
        }


        public void MostrarEstadoParqueo()//muetra el estado general de todo el parque
        {

            Console.WriteLine("Estado General del Parqueo:");
            Console.WriteLine("Niveles: " + Nivel);
            Console.WriteLine("Espacios por nivel: " + EspaciosPorNivel);
            Console.WriteLine("Total espacios: " + Nivel * EspaciosPorNivel);
            Console.WriteLine();

            int motosOcupados = 0;
            int suvsOcupados = 0;
            int estandarOcupados = 0;
            int motosLibres = 0;
            int suvsLibres = 0;
            int estandarLibres = 0;

            foreach (var espacio in Espacios)//contamos todo los espacion segun su tipo
            {
                if (espacio.Tipo == "Moto")
                {
                    if (!espacio.Disponibilidad) motosOcupados++;
                    else motosLibres++;
                }
                else if (espacio.Tipo == "SUV")
                {
                    if (!espacio.Disponibilidad) suvsOcupados++;
                    else suvsLibres++;
                }
                else if (espacio.Tipo == "Estandar")
                {
                    if (!espacio.Disponibilidad) estandarOcupados++;
                    else estandarLibres++;
                }
            }

            Console.WriteLine("Espacios para Motos");//mostramos los datos por tipos
            Console.WriteLine("Total: " + EspaciosMotos);
            Console.WriteLine("Ocupados: " + motosOcupados);
            Console.WriteLine("Disponibles: " + motosLibres);
            Console.WriteLine();
            Console.WriteLine("Espacios para SUV");
            Console.WriteLine("Total: " + EspaciosSuv);
            Console.WriteLine("Ocupados: " + suvsOcupados);
            Console.WriteLine("Disponibles: " + suvsLibres);
            Console.WriteLine();
            Console.WriteLine("Espacios para Vehículos Estándar");
            Console.WriteLine("Total: " + EspaciosEstandar);
            Console.WriteLine("Ocupados: " + estandarOcupados);
            Console.WriteLine("Disponibles: " + estandarLibres);
            Console.WriteLine();

            Console.WriteLine("Mapa del estacionamiento (M# = Motos, S# = Suv, E# = Estandar, X = Ocupados):");
            for (int i = 1; i <= this.GetNivel(); i++)//contador que muestra los arreglos en por niveles formando matriz
            {
                Console.WriteLine("Nivel " + i);
                foreach (var espacio in this.Espacios.Where(e => e.GetNivel() == i))
                {
                    string simbolo = espacio.Disponibilidad ? espacio.GetCodigo() : "X";
                    Console.Write(simbolo + " ");
                }
                Console.WriteLine("");
            }
            Console.WriteLine();
        }

        public void IngresarVehiculos()//funcion que igresara los datos del vehiculos
        {
            Console.Write("Marca del vehículo: ");
            string Marca = Console.ReadLine();

            Console.Write("Color del vehículo: ");
            string Color = Console.ReadLine();

            string Placa;
            while (true)//ciclo que se repite hasta ingrese correctamente el formato de la placa
            {
                Console.Write("Placa del vehículo (Ingrese con el siguiente formato: 123ABC): ");
                Placa = Console.ReadLine().Trim().ToUpper();

                if (Vehiculos.ValidarPlaca(Placa))
                {
                    break;
                }

                Console.WriteLine("Error: La placa debe tener 3 números seguidos de 3 letras, intente nuevamente.");
            }

            string Tipo = "";
            while (true)//ciclo que se repite hasta que se ingrese uno de los tipos de vehiculos disponibles 
            {
                Console.Write("Cual es el tipo de vehículo (Moto, SUV o Estandar): ");
                Tipo = Console.ReadLine().Trim().ToUpper();

                if (Tipo == "MOTO" || Tipo == "SUV" || Tipo == "ESTANDAR")
                {
                    int espaciosDisponibles = this.Espacios.Count(e => e.Disponibilidad && e.Tipo.Equals(Tipo, StringComparison.OrdinalIgnoreCase));
                    if (espaciosDisponibles > 0)
                    {
                        break;
                    }
                    else
                    {
                        Console.WriteLine("No hay espacios disponibles para vehículos tipo " + Tipo);
                    }
                }
                else
                {
                    Console.WriteLine("Tipo de vehículo inválido, intente nuevamente");
                }
            }

            int HoraEntrada;
            while (true)
            {
                Console.Write("Hora de entrada (entre 5 y 17): ");
                if (int.TryParse(Console.ReadLine().Trim(), out HoraEntrada) && HoraEntrada >= 5 && HoraEntrada <= 17)
                    break;
                Console.WriteLine("Error: La hora de ingrese es de 5:00 AM a 17:00 PM");
            }

            if (this.Espacios == null || this.Espacios.Count == 0)
            {
                Console.WriteLine("Error: El parqueo no ha sido inicializado correctamente.");
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine("Mapa del estacionamiento (M# = Motos, S# = Suv, E# = Estandar, X = Ocupados):");
                Console.WriteLine("");

                for (int i = 1; i <= this.GetNivel(); i++)
                {
                    Console.WriteLine("Nivel " + i);
                    foreach (var espacio in this.Espacios.Where(e => e.GetNivel() == i))
                    {
                        string simbolo = espacio.Disponibilidad ? espacio.GetCodigo() : "X";
                        Console.Write(simbolo + " ");
                    }
                    Console.WriteLine("");
                }
                Console.WriteLine();
            }

            Vehiculos nuevoVehiculo = new Vehiculos(Marca, Color, Placa, Tipo, DateTime.Now);

            string Codigo = "";
            while (true)
            {
                Console.WriteLine();
                Console.Write("Ingrese el código del estacionamiento donde desea parquear el vehículo: ");
                Codigo = Console.ReadLine().Trim().ToUpper();

                var espacioSeleccionado = this.Espacios.FirstOrDefault(e => e.GetCodigo().Equals(Codigo, StringComparison.OrdinalIgnoreCase));

                if (espacioSeleccionado != null)
                {

                    if (espacioSeleccionado.Disponibilidad && espacioSeleccionado.Tipo.Equals(Tipo, StringComparison.OrdinalIgnoreCase))
                    {
                        espacioSeleccionado.AsignarVehiculo(nuevoVehiculo);
                        Console.WriteLine();
                        Console.WriteLine("Vehículo con placa " + Placa + " se asigno al espacio " + Codigo);
                        Console.WriteLine();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Error: El espacio ingresado no es válido para el tipo de vehiculo o está ocupado");
                    }
                }
                else
                {
                    Console.WriteLine("Error: El espacio ingresado no es válido o está ocupado");
                }
            }
            Console.WriteLine();
            Console.WriteLine("Vehículo parqueado correctamente");

            Console.WriteLine();
        }

        public void IngresarLotedeVehiculos()
        {
            Random Random = new Random();
            string[] Marcas = { "Honda", "Nissan", "Hyundai", "Toyota", "Kia" };
            string[] Colores = { "Rojo", "Azul", "Negro", "Gris", "Blanco" };
            string[] Tipos = { "Moto", "Suv", "Estandar" };

            for (int i = 0; i < 5; i++)
            {
                string Marca = Marcas[Random.Next(Marcas.Length)];
                string Color = Colores[Random.Next(Colores.Length)];
                string Tipo = Tipos[Random.Next(Tipos.Length)];
                string Placa = PlacaAleatoria();
                int HoraEntrada = Random.Next(5, 18);

                DateTime horaRegistrada = DateTime.Today.AddHours(HoraEntrada);

                var espacioDisponible = this.Espacios.FirstOrDefault(e => e.Disponibilidad && e.Tipo.Equals(Tipo, StringComparison.OrdinalIgnoreCase));
                Vehiculos nuevoVehiculo = new Vehiculos(Marca, Color, Placa, Tipo, horaRegistrada);

                if (espacioDisponible != null)
                {
                    espacioDisponible.AsignarVehiculo(nuevoVehiculo);
                    Console.WriteLine("Vehículo " + Placa + " de tipo " + Tipo + " se asignado al espacio " + espacioDisponible.GetCodigo());
                }
                else
                {
                    Console.WriteLine("No hay espacio disponible para vehiculos de tipo " + Tipo + " con placa " + Placa + " , no puede ingresar");
                }
            }
            Console.WriteLine();
            MostrarEstadoParqueo();
        }
        private string PlacaAleatoria()
        {
            Random Random = new Random();
            string letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string numeros = "0123456789";

            string placa = new string(Enumerable.Range(0, 3).Select(_ => numeros[Random.Next(numeros.Length)]).ToArray()) +
            new string(Enumerable.Range(0, 3).Select(_ => letras[Random.Next(letras.Length)]).ToArray());

            return placa;
        }

        public void BuscarVehiculos()
        {
            Console.WriteLine("Ingrese la placa del vehiculo que desea buscar");
            string Buscar = Console.ReadLine().Trim().ToUpper();

            var espacioEncontrado = this.Espacios.FirstOrDefault(e => !e.Disponibilidad && e.VehiculoAsignado != null && e.VehiculoAsignado.GetPlaca().Equals(Buscar, StringComparison.OrdinalIgnoreCase));
            if (espacioEncontrado != null)
            {
                Vehiculos vehiculo = espacioEncontrado.VehiculoAsignado;
                Console.WriteLine("Placa: " + vehiculo.GetPlaca());
                Console.WriteLine("Marca: " + vehiculo.GetMarca());
                Console.WriteLine("Color: " + vehiculo.GetColor());
                Console.WriteLine("Tipo: " + vehiculo.GetTipo());
                Console.WriteLine("Estacionado en: " + espacioEncontrado.GetCodigo());
            }
            else
            {
                Console.WriteLine("No se encontró ningún vehículo con la placa ingresada");
            }
        }

        public void ReporteDeVehiculosEstacionados()
        {
            int opciones;
            int HoraEntrada = 0;
            string BuscarTipo = "";

            Console.WriteLine("Para generar el reporte de vehiculos elija una de las siguientes opciones de busqueda para el vehiculo");
            Console.WriteLine("1. Buscar por hora de entrada");
            Console.WriteLine("2. Buscar por tipo de vehículo");

            while (!int.TryParse(Console.ReadLine(), out opciones) || (opciones < 1 || opciones > 2))
            {
                Console.WriteLine("Opción inválida, ingrese 1 o 2");
            }
            Console.WriteLine();


            if (opciones == 1)
            {
                Console.Write("Ingrese la hora de entrada (5 a 17): ");
                while (!int.TryParse(Console.ReadLine(), out HoraEntrada) || (HoraEntrada < 5 || HoraEntrada > 17))
                {
                    Console.WriteLine("Error: Ingrese una hora válida entre 5 y 17.");
                }

                Console.WriteLine("Vehículos estacionados con hora de entrada " + HoraEntrada + ":00");
            }
            else
            {
                Console.Write("Ingrese el tipo de vehículo a buscar (Moto, SUV, Estandar): ");
                BuscarTipo = Console.ReadLine().Trim().ToUpper();

                Console.WriteLine("Vehículos estacionados del tipo " + BuscarTipo);
            }
            bool encontrado = false;

            foreach (var espacio in this.Espacios)
            {
                if (!espacio.Disponibilidad && espacio.VehiculoAsignado != null)
                {
                    Vehiculos v = espacio.VehiculoAsignado;

                    bool Valido = (opciones == 1 && v.GetHoraEntrada().Hour == HoraEntrada) || (opciones == 2 && v.GetTipo().Equals(BuscarTipo, StringComparison.OrdinalIgnoreCase));

                    if (Valido)
                    {
                        Console.WriteLine($"Placa: {v.GetPlaca(),-7}");
                        Console.WriteLine($"Marca: {v.GetMarca(),-7}");
                        Console.WriteLine($"Color: {v.GetColor(),-6}");
                        Console.WriteLine($"Tipo: {v.GetTipo(),-6}");
                        Console.WriteLine($"Hora de Entrada: {v.GetHoraEntrada().Hour}:00");
                        Console.WriteLine($"Espacio: {espacio.GetCodigo()}");
                        encontrado = true;
                    }
                }
            }
            if (!encontrado)
            {
                Console.WriteLine("No hay vehículos que coincidan con el daro ingresado");
            }
        }
        public Estacionamiento? BuscarCodigo(string codigo)
        {
            return Espacios.FirstOrDefault(e => e.GetCodigo().Equals(codigo, StringComparison.OrdinalIgnoreCase));
        }
        public void RetirarVehiculo()
        {
            Pago.RetirarVehiculo(this);
        }
    }


}