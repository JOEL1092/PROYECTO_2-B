using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;

namespace PROYECTO_2.Clases
{
    public class Vehiculos//clase que contienen los datos del vehiculos
    {
        private string Marca;//variable que guardara la marca del vehiculo
        private string Color;//variable que guardara el color del vehiculo
        private string Placa;//variable que guardara la placa del vheiculo
        private string Tipo;//variable que guardara el tipo de vehiculo
        private DateTime HoraEntrada;//variable que guardara el formato de hora en que ingresa

        public Vehiculos(string Marca, string Color, string Placa, string Tipo, DateTime HoraEntrada)///creamos una funcion con contrendra las constructoras
        {
            this.Marca = Marca;
            this.Color = Color;
            this.Placa = Placa;
            this.Tipo = Tipo;
            this.HoraEntrada = HoraEntrada;
        }

        public void SetMarca(string Marca)
        {
            if (!string.IsNullOrWhiteSpace(Marca))
            {
                this.Marca = Marca;
            }
            else
            {
                throw new ArgumentException("Error: Debe de ingresar la marca del vehiculo");
            }

        }

        public string GetMarca()
        {
            return this.Marca;
        }
        public void SetColor(string Color)
        {
            if (!string.IsNullOrWhiteSpace(Color))
            {
                this.Color = Color;
            }
            else
            {
                throw new ArgumentException("Error: Debe de ingresar el color del vehiculo");
            }
        }
        public string GetColor()
        {
            return this.Color;
        }
        public void SetPlaca(string Placa)
        {
            this.Placa = Placa;
        }
    
        public string GetPlaca()
        {
            return this.Placa;
        }
        public void SetTipo(string Tipo)
        {
            this.Tipo = Tipo;
        }
        public string GetTipo()
        {
            return this.Tipo;
        }
        public void SetHoraEntrada(DateTime HoraEntrada)
        {
            this.HoraEntrada = HoraEntrada;
        }
        public DateTime GetHoraEntrada()
        {
            return this.HoraEntrada;
        }

        public static bool ValidarPlaca(string Placa)//funcion que validara el formato de la placa 
        {
            if (Placa.Length == 6)//si la placa tienen 6 caraceres realizara el conteo de los primero 3 valores para que sean nuemeros y los 3 utlimos para que sean letras
            {
                for (int i = 0; i < 3; i++)//conteo de los primero 3 valores
                {
                    if (!char.IsDigit(Placa[i]))//compara si es nuemero o no
                    {
                        return false;
                    }
                }
                for (int i = 3; i < 6; i++)//conteo de los 3 ultimos valores
                {
                    if (!char.IsLetter(Placa[i]))//compara si es letra no
                    {
                        return false;
                    }
                }
                return true;
            }
              return false;
        }
    }

}