using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.IO.Pipes;

namespace PROYECTO_2.Clases
{
    public class Estacionamiento//clase que contienen los datos de estacionamietno individual
    {
        public string Codigo;//variable que guardara el codigo
        public string Tipo;//variable que guardara el tipo de vehiculo 
        public int Nivel;//variable que guardara la cantidad de niveles
        public bool Disponibilidad;//variable que duardara la disponibilidad el espacio
        public Vehiculos? VehiculoAsignado { get; private set; }//se llama la clase de vehiculos

        public Estacionamiento(string Codigo, string Tipo, int Nivel, bool Disponibilidad)//clase que contienen los constructores de las variables
        {
            this.Codigo = Codigo;
            this.Tipo = Tipo;
            this.Nivel = Nivel;
            this.Disponibilidad = Disponibilidad;
        }

        public void SetCodigo(string Codigo)//metodos de las variables
        {
            this.Codigo = Codigo;
        }
        public string GetCodigo()
        {
            return this.Codigo;
        }
        public void SetTipo(string Tipo)
        {
            this.Tipo = Tipo;
        }
        public string GetTipo()
        {
            return this.Tipo;
        }
        public void SetNivel(int Nivel)
        {
            this.Nivel = Nivel;
        }
        public int GetNivel()
        {
            return this.Nivel;
        }

        public bool AsignarVehiculo(Vehiculos vehiculo)//funcion que asignara un vehiculo en un parqueo de su tipo y la disponibilidad
        {
            if (Disponibilidad && vehiculo.GetTipo().Equals(Tipo, StringComparison.OrdinalIgnoreCase))//compara la disponibilidad y el tipo con el espacio
            {
                VehiculoAsignado = vehiculo;
                Disponibilidad = false;
                return true;
            }

            Console.WriteLine("No se pudo asignar el vehículo " + vehiculo.GetPlaca() + " Espacio no disponible o incorrecto");
            return false;
        }

        public void LiberarEspacio()//funcion que libera el espacio del vehiculo
        {
            if (!Disponibilidad && VehiculoAsignado != null)//compara la disponibulidad con el veiculo asignado
            {
                Console.WriteLine("Vehículo " + VehiculoAsignado?.GetPlaca() + " ha salido del espacio " + Codigo);
                VehiculoAsignado = null;
                Disponibilidad = true;
            }
            else
            {
                Console.WriteLine("Espacio " + Codigo + " ya está libre");
            }

        }

    }

}